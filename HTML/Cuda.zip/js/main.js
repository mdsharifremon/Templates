$(document).ready(function(){
  /////////////// HAMBURGER MENU ON MOBILE DEVICE
  $(".menu-bar").click(function (event) {
    event.stopPropagation();
    $("#main-ul").toggleClass("slide-back");
    $(".wrap").toggleClass("slide-left");
  });

  $(".wrap,a").click(function () {
    $("#main-ul").removeClass("slide-back");
    if ($(".wrap").hasClass("slide-left")) {
      $(".wrap").removeClass("slide-left");
    }
  });
  ///// TABS ON PORTPOLIO SECTION/////////////
  $(".filter:first").addClass("active");
  $(".tab:first").fadeIn().addClass("show");
  $(".filter").click(function () {
    var index = $(this).index();
    $(".filter").removeClass("active");
    $(this).addClass("active");
    $(".tab").stop(true, true).fadeOut(0).removeClass("show");
    $(".tab").eq(index).stop(true, true).fadeIn(700).addClass("show");
  });
  ////// MORE PORJECT BUTTON ON PORTFOLIO SECTION
  $("#more-project").click(function () {
    $(".filter").removeClass("active");
    $(".filter:first").addClass("active");
    $(".tab").stop(true, true).fadeOut(0).removeClass("show");
    $(".tab:first").stop(true, true).fadeIn(700).addClass("show");;
  });

  //////////////// STICKY MENU (SERVICE SECTION)
     $("#our-service").waypoint(function (direction) {
       if (direction == "down") {
         $("#sticky").addClass("sticky-menu");
       } else {
         $("#sticky").removeClass("sticky-menu");
       }
     });

   //////////////// ACTIVE LINK ON MENU
      $("#main-menu a:first").addClass("active");
   $("#main-menu a").click(function(){
        $("#main-menu a").removeClass("active");
        $(this).addClass("active");
    });

    $("#our-logo").click(function () {
          $("#main-menu a").removeClass("active");
          $("#main-menu a:first").addClass("active");
     });

});