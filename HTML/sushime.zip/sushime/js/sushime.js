
$( document ).ready(function() {
///////// MENU BAR ACTIVE LINKS ON HEADER SECTION
$( ".top ul li a" ).click(function() {
    $('.top ul li a').removeClass('active');
    $(this).addClass('active');
});

/////////////// HUMBURGER CLICK TOGGLE MENU

$(".humburger").click(function(){
    $("#mobile").toggleClass('slide');
})

//////////// SCROLL TO TOP
 $('.scrollTop').hide();
   window.onscroll = function(){
     if(document.body.scrollTop > 300 || document.documentElement.scrollTop >300){
       $('.scrollTop').show();
     }else{
       $('.scrollTop').hide();
     }
//////////////// STICKY MENU (SERVICE SECTION)
     if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
        $("#extra").addClass("extra");
       $("#sticky").addClass("sticky-menu");

     } else {
         $("#extra").removeClass("extra");
         $("#sticky").removeClass("sticky-menu");
       }
   }
});




