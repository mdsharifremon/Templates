
$( document ).ready(function() {
///////// MENU BAR ACTIVE LINKS ON HEADER SECTION
$( ".top ul li a" ).click(function() {
    $('.top ul li a').removeClass('active');
    $(this).addClass('active');
});

/////////////// TOGGLE MENU

    $(".humburger").click(function () {
        $(".mobile-device").toggleClass('slide');
        $("section").toggleClass('slide-back');
    });
    $(".logo,section,.mobile-device li a").click(function () {
        $(".mobile-device").removeClass('slide');
        if ($("section").hasClass('slide-back')) {
            $("section").removeClass('slide-back');
        }
    });
//////////// SCROLL TO TOP
 $('.scrollTop').hide();
   window.onscroll = function(){
     if(document.body.scrollTop > 300 || document.documentElement.scrollTop >300){
       $('.scrollTop').show();
     }else{
       $('.scrollTop').hide();
     }
//////////////// STICKY MENU (SERVICE SECTION)
       if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
           $("#sticky").addClass("sticky-menu");
       } else {
           $("#sticky").removeClass("sticky-menu");
       }
  }
//////////////// ACCORDION ON FAQ SECTION
  $('.accordion-content').first().show();
  $('.accordion-heading').click(function () {
    $(this).next('.accordion-content').slideToggle(300);
    $(this).find('span').toggle();
  });


///////  Price Button
  $('.price-btn .btn').first().addClass('active');
  $('.price-btn .btn').hover(function () {
    $('.price-btn .btn').removeClass('active');
    $(this).addClass('active');
  });


    $('.link .btn').first().addClass('active');
  $('.link .btn').hover(function () {
    $('.link .btn').removeClass('active');
    $(this).addClass('active');
  })


//////////////// TABS ON STORY SECTION
    $('.tab-btn span').last().addClass('active');
  $('.tab-btn span').hover(function () {
    $('.tab-btn span').removeClass('active');
    $(this).addClass('active');
  })


  //// Price Card
  $('.card').first().addClass('active');
  $('.card').hover(function () {
    $('.card').removeClass('active');
    $(this).addClass('active');
  });
    
// Footer Social Links
    $('.social-links a').hover(function(){
        $('.social-links a').removeClass('active');
        $(this).addClass('active');
    });

});




